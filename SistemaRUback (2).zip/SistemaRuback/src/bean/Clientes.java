/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bean;
import java.util.Date;
/**
 *
 * @author vic
 */
public class Clientes {

    /**
     * @return the var_idCliente
     */
    public int getVar_idCliente() {
        return var_idCliente;
    }

    /**
     * @param var_idCliente the var_idCliente to set
     */
    public void setVar_idCliente(int var_idCliente) {
        this.var_idCliente = var_idCliente;
    }

    /**
     * @return the var_nome
     */
    public String getVar_nome() {
        return var_nome;
    }

    /**
     * @param var_nome the var_nome to set
     */
    public void setVar_nome(String var_nome) {
        this.var_nome = var_nome;
    }

    /**
     * @return the var_cpf
     */
    public String getVar_cpf() {
        return var_cpf;
    }

    /**
     * @param var_cpf the var_cpf to set
     */
    public void setVar_cpf(String var_cpf) {
        this.var_cpf = var_cpf;
    }

    /**
     * @return the var_rg
     */
    public String getVar_rg() {
        return var_rg;
    }

    /**
     * @param var_rg the var_rg to set
     */
    public void setVar_rg(String var_rg) {
        this.var_rg = var_rg;
    }

    /**
     * @return the var_sexo
     */
    public String getVar_sexo() {
        return var_sexo;
    }

    /**
     * @param var_sexo the var_sexo to set
     */
    public void setVar_sexo(String var_sexo) {
        this.var_sexo = var_sexo;
    }

    /**
     * @return the var_dataNascimento
     */
    public Date getVar_dataNascimento() {
        return var_dataNascimento;
    }

    /**
     * @param var_dataNascimento the var_dataNascimento to set
     */
    public void setVar_dataNascimento(Date var_dataNascimento) {
        this.var_dataNascimento = var_dataNascimento;
    }

    /**
     * @return the var_email
     */
    public String getVar_email() {
        return var_email;
    }

    /**
     * @param var_email the var_email to set
     */
    public void setVar_email(String var_email) {
        this.var_email = var_email;
    }

    /**
     * @return the var_endereco
     */
    public String getVar_endereco() {
        return var_endereco;
    }

    /**
     * @param var_endereco the var_endereco to set
     */
    public void setVar_endereco(String var_endereco) {
        this.var_endereco = var_endereco;
    }

    /**
     * @return the var_telefone
     */
    public String getVar_telefone() {
        return var_telefone;
    }

    /**
     * @param var_telefone the var_telefone to set
     */
    public void setVar_telefone(String var_telefone) {
        this.var_telefone = var_telefone;
    }

    /**
     * @return the var_celular
     */
    public String getVar_celular() {
        return var_celular;
    }

    /**
     * @param var_celular the var_celular to set
     */
    public void setVar_celular(String var_celular) {
        this.var_celular = var_celular;
    }

    /**
     * @return the var_dataCadastro
     */
    public Date getVar_dataCadastro() {
        return var_dataCadastro;
    }

    /**
     * @param var_dataCadastro the var_dataCadastro to set
     */
    public void setVar_dataCadastro(Date var_dataCadastro) {
        this.var_dataCadastro = var_dataCadastro;
    }

    /**
     * @return the var_ativo
     */
    public String getVar_ativo() {
        return var_ativo;
    }

    /**
     * @param var_ativo the var_ativo to set
     */
    public void setVar_ativo(String var_ativo) {
        this.var_ativo = var_ativo;
    }

    /**
     * @return the var_dataUltimaCompra
     */
    public Date getVar_dataUltimaCompra() {
        return var_dataUltimaCompra;
    }

    /**
     * @param var_dataUltimaCompra the var_dataUltimaCompra to set
     */
    public void setVar_dataUltimaCompra(Date var_dataUltimaCompra) {
        this.var_dataUltimaCompra = var_dataUltimaCompra;
    }

    /**
     * @return the var_limiteCredito
     */
    public double getVar_limiteCredito() {
        return var_limiteCredito;
    }

    /**
     * @param var_limiteCredito the var_limiteCredito to set
     */
    public void setVar_limiteCredito(double var_limiteCredito) {
        this.var_limiteCredito = var_limiteCredito;
    }
    
     private int var_idCliente;
     private String var_nome;
     private String var_cpf;
     private String var_rg;
     private String var_sexo;
     private Date var_dataNascimento;
     private String var_email;
     private String var_endereco;
     private String var_telefone;
     private String var_celular;
     private Date var_dataCadastro;
     private String var_ativo;
     private Date var_dataUltimaCompra;
     private double var_limiteCredito;
}
