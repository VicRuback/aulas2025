/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bean;

import java.sql.Date;

/**
 *
 * @author clari
 */
public class Vendedor {

    /**
     * @return the var_id_vendedor
     */
    private int var_id_vendedor;
    private String var_nome;
    private String var_apelido;
    private String var_cpf;
    private String var_email;
    private Date var_data_nascimento;
    private String var_telefone;
    private String var_ativo;

    public int getVar_id_vendedor() {
        return var_id_vendedor;
    }

    /**
     * @param var_id_vendedor the var_id_vendedor to set
     */
    public void setVar_id_vendedor(int var_id_vendedor) {
        this.var_id_vendedor = var_id_vendedor;
    }

    /**
     * @return the var_nome
     */
    public String getVar_nome() {
        return var_nome;
    }

    /**
     * @param var_nome the var_nome to set
     */
    public void setVar_nome(String var_nome) {
        this.var_nome = var_nome;
    }

    /**
     * @return the var_apelido
     */
    public String getVar_apelido() {
        return var_apelido;
    }

    /**
     * @param var_apelido the var_apelido to set
     */
    public void setVar_apelido(String var_apelido) {
        this.var_apelido = var_apelido;
    }

    /**
     * @return the var_cpf
     */
    public String getVar_cpf() {
        return var_cpf;
    }

    /**
     * @param var_cpf the var_cpf to set
     */
    public void setVar_cpf(String var_cpf) {
        this.var_cpf = var_cpf;
    }

    /**
     * @return the var_email
     */
    public String getVar_email() {
        return var_email;
    }

    /**
     * @param var_email the var_email to set
     */
    public void setVar_email(String var_email) {
        this.var_email = var_email;
    }

    /**
     * @return the var_data_nascimento
     */
    public Date getVar_data_nascimento() {
        return var_data_nascimento;
    }

    /**
     * @param var_data_nascimento the var_data_nascimento to set
     */
    public void setVar_data_nascimento(Date var_data_nascimento) {
        this.var_data_nascimento = var_data_nascimento;
    }

    /**
     * @return the var_telefone
     */
    public String getVar_telefone() {
        return var_telefone;
    }

    /**
     * @param var_telefone the var_telefone to set
     */
    public void setVar_telefone(String var_telefone) {
        this.var_telefone = var_telefone;
    }

    /**
     * @return the var_ativo
     */
    public String getVar_ativo() {
        return var_ativo;
    }

    /**
     * @param var_ativo the var_ativo to set
     */
    public void setVar_ativo(String var_ativo) {
        this.var_ativo = var_ativo;
    }

}
