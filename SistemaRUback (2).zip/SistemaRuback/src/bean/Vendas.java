/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bean;
import java.util.Date;
/**
 *
 * @author vic
 */
public class Vendas {

    /**
     * @return the var_idVendas
     */
    public int getVar_idVendas() {
        return var_idVendas;
    }

    /**
     * @param var_idVendas the var_idVendas to set
     */
    public void setVar_idVendas(int var_idVendas) {
        this.var_idVendas = var_idVendas;
    }

    /**
     * @return the var_dataVendas
     */
    public Date getVar_dataVendas() {
        return var_dataVendas;
    }

    /**
     * @param var_dataVendas the var_dataVendas to set
     */
    public void setVar_dataVendas(Date var_dataVendas) {
        this.var_dataVendas = var_dataVendas;
    }

    /**
     * @return the var_cliente
     */
    public int getVar_cliente() {
        return var_cliente;
    }

    /**
     * @param var_cliente the var_cliente to set
     */
    public void setVar_cliente(int var_cliente) {
        this.var_cliente = var_cliente;
    }

    /**
     * @return the var_usuario
     */
    public int getVar_usuario() {
        return var_usuario;
    }

    /**
     * @param var_usuario the var_usuario to set
     */
    public void setVar_usuario(int var_usuario) {
        this.var_usuario = var_usuario;
    }

    /**
     * @return the var_total
     */
    public double getVar_total() {
        return var_total;
    }

    /**
     * @param var_total the var_total to set
     */
    public void setVar_total(double var_total) {
        this.var_total = var_total;
    }
     private int var_idVendas;
     private Date var_dataVendas;
     private int var_cliente;
     private int var_usuario;
     private double var_total;
}
