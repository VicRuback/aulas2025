/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bean;

/**
 *
 * @author vic
 */
public class Bolsas {
    
     private int var_id_bolsas;
     private String var_nome;
     private String var_categoria;
     private String var_coloracao;
     private String var_descricao;
     private double var_preco;
     private String var_ativo;
     private int var_colecao;
    /**
     * @return the var_id_bolsas
     */
    public int getVar_id_bolsas() {
        return var_id_bolsas;
    }

    /**
     * @param var_id_bolsas the var_id_bolsas to set
     */
    public void setVar_id_bolsas(int var_id_bolsas) {
        this.var_id_bolsas = var_id_bolsas;
    }

    /**
     * @return the var_nome
     */
    public String getVar_nome() {
        return var_nome;
    }

    /**
     * @param var_nome the var_nome to set
     */
    public void setVar_nome(String var_nome) {
        this.var_nome = var_nome;
    }

    /**
     * @return the var_categoria
     */
    public String getVar_categoria() {
        return var_categoria;
    }

    /**
     * @param var_categoria the var_categoria to set
     */
    public void setVar_categoria(String var_categoria) {
        this.var_categoria = var_categoria;
    }

    /**
     * @return the var_coloracao
     */
    public String getVar_coloracao() {
        return var_coloracao;
    }

    /**
     * @param var_coloracao the var_coloracao to set
     */
    public void setVar_coloracao(String var_coloracao) {
        this.var_coloracao = var_coloracao;
    }

    /**
     * @return the var_descricao
     */
    public String getVar_descricao() {
        return var_descricao;
    }

    /**
     * @param var_descricao the var_descricao to set
     */
    public void setVar_descricao(String var_descricao) {
        this.var_descricao = var_descricao;
    }

    /**
     * @return the var_preco
     */
    public double getVar_preco() {
        return var_preco;
    }

    /**
     * @param var_preco the var_preco to set
     */
    public void setVar_preco(double var_preco) {
        this.var_preco = var_preco;
    }

    /**
     * @return the var_ativo
     */
    public String getVar_ativo() {
        return var_ativo;
    }

    /**
     * @param var_ativo the var_ativo to set
     */
    public void setVar_ativo(String var_ativo) {
        this.var_ativo = var_ativo;
    }

    /**
     * @return the var_colecao
     */
    public int getVar_colecao() {
        return var_colecao;
    }

    /**
     * @param var_colecao the var_colecao to set
     */
    public void setVar_colecao(int var_colecao) {
        this.var_colecao = var_colecao;
    }

}
