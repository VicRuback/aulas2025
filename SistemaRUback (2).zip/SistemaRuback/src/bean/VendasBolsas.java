/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bean;

/**
 *
 * @author vic
 */
public class VendasBolsas {

    /**
     * @return the var_id
     */
    public int getVar_id() {
        return var_id;
    }

    /**
     * @param var_id the var_id to set
     */
    public void setVar_id(int var_id) {
        this.var_id = var_id;
    }

    /**
     * @return the var_idVenda
     */
    public int getVar_idVenda() {
        return var_idVenda;
    }

    /**
     * @param var_idVenda the var_idVenda to set
     */
    public void setVar_idVenda(int var_idVenda) {
        this.var_idVenda = var_idVenda;
    }

    /**
     * @return the var_idBolsa
     */
    public int getVar_idBolsa() {
        return var_idBolsa;
    }

    /**
     * @param var_idBolsa the var_idBolsa to set
     */
    public void setVar_idBolsa(int var_idBolsa) {
        this.var_idBolsa = var_idBolsa;
    }

    /**
     * @return the var_quantidade
     */
    public int getVar_quantidade() {
        return var_quantidade;
    }

    /**
     * @param var_quantidade the var_quantidade to set
     */
    public void setVar_quantidade(int var_quantidade) {
        this.var_quantidade = var_quantidade;
    }

    /**
     * @return the var_precoUnitario
     */
    public double getVar_precoUnitario() {
        return var_precoUnitario;
    }

    /**
     * @param var_precoUnitario the var_precoUnitario to set
     */
    public void setVar_precoUnitario(double var_precoUnitario) {
        this.var_precoUnitario = var_precoUnitario;
    }
         private int var_id;
     private int var_idVenda;
     private int var_idBolsa;
     private int var_quantidade;
     private double var_precoUnitario;
}