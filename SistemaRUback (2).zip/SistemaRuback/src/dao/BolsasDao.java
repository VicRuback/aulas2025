/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import bean.Bolsas;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author marcos
 */
public class BolsasDao extends DaoAbstract {

    Connection cnt;

    public BolsasDao() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url, user, pass;
            //url = "jdbc:mysql://10.7.0.51:330622/db_marcos_vilhanueva";
            //user = "marcos_vilhanueva";
            //pass = "marcos_vilhanueva";
            url = "jdbc:mysql://10.7.0.51:33062/db_victoria_ruback";
            user = "victoria_ruback";
            pass = "victoria_ruback";
            cnt = DriverManager.getConnection(url, user, pass);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(BolsasDao.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(BolsasDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void insert(Object object) {
        Bolsas bolsas = (Bolsas) object;
        try {
            PreparedStatement pst = cnt.prepareStatement("insert into var_bolsas values(?,?,?,?,?,?,?,?)");
            pst.setInt(1, bolsas.getVar_id_bolsas());
            pst.setString(2, bolsas.getVar_nome());
            pst.setString(3, bolsas.getVar_categoria());
            pst.setString(4, bolsas.getVar_coloracao());
            pst.setString(5, bolsas.getVar_descricao());
            pst.setDouble(6, bolsas.getVar_preco());
            pst.setString(7, bolsas.getVar_ativo());
            pst.setInt(8, bolsas.getVar_colecao());
            pst.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(BolsasDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void update(Object object) {
        Bolsas bolsas = (Bolsas) object;
        try {
            PreparedStatement pst = cnt.prepareStatement(
                    "update var_bolsas set var_nome=?, var_categoria=?, var_coloracao=?, var_descricao=?, var_preco=?, var_ativo=?, var_colecao=? where var_id_bolsas=?"
            );

            pst.setString(1, bolsas.getVar_nome());
            pst.setString(2, bolsas.getVar_categoria());
            pst.setString(3, bolsas.getVar_coloracao());
            pst.setString(4, bolsas.getVar_descricao());
            pst.setDouble(5, bolsas.getVar_preco());
            pst.setString(6, bolsas.getVar_ativo());
            pst.setInt(7, bolsas.getVar_colecao());
            pst.setInt(8, bolsas.getVar_id_bolsas());

            pst.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(BolsasDao.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @Override
    public void delete(Object object) {
        Bolsas bolsas = (Bolsas) object;
        try {
            PreparedStatement pst = cnt.prepareStatement("delete from var_bolsas where var_id_bolsas = ?");
            pst.setInt(1, bolsas.getVar_id_bolsas());
            pst.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(BolsasDao.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @Override
    public Object list(int id) {
        PreparedStatement pst;
        try {
            pst = cnt.prepareStatement("select * from var_bolsas where var_id_bolsas = ?");
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                Bolsas bolsas = new Bolsas();
                bolsas.setVar_id_bolsas(rs.getInt("var_id_bolsas"));
                bolsas.setVar_nome(rs.getString("var_nome"));
                bolsas.setVar_categoria(rs.getString("var_categoria"));
                bolsas.setVar_coloracao(rs.getString("var_coloracao"));
                bolsas.setVar_descricao(rs.getString("var_descricao"));
                bolsas.setVar_preco(rs.getDouble("var_preco"));
                bolsas.setVar_ativo(rs.getString("var_ativo"));
                bolsas.setVar_colecao(rs.getInt("var_colecao"));
                return bolsas;
            }
        } catch (SQLException ex) {
            Logger.getLogger(BolsasDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;

    }

    @Override
    public Object listAll() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public static void main(String[] args) {
        Bolsas bolsa = new Bolsas();

        // Preenchendo com dados demonstrativos
        bolsa.setVar_id_bolsas(1);
        bolsa.setVar_nome("Bolsa Elegance Médio");
        bolsa.setVar_categoria("Clássica");
        bolsa.setVar_coloracao("Preto");
        bolsa.setVar_descricao("Bolsa em couro legítimo com alça ajustável e compartimento interno");
        bolsa.setVar_preco(299.90);
        bolsa.setVar_ativo("S");
        bolsa.setVar_colecao(2023);

        // Inserindo no banco de dados
        BolsasDao bolsasDao = new BolsasDao();
        bolsasDao.insert(bolsa);

        System.out.println("Bolsa cadastrada com sucesso!");
        System.out.println("ID: " + bolsa.getVar_id_bolsas());
        System.out.println("Nome: " + bolsa.getVar_nome());
        System.out.println("Categoria: " + bolsa.getVar_categoria());
        System.out.println("Preço: R$ " + bolsa.getVar_preco());
        System.out.println("Coleção: " + bolsa.getVar_colecao());
    }

}
