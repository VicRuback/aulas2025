/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import bean.Clientes;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author marcos
 */
public class ClientesDao extends DaoAbstract {

    Connection cnt;

    public ClientesDao() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url, user, pass;
            //url = "jdbc:mysql://10.7.0.51:330622/db_marcos_vilhanueva";
            //user = "marcos_vilhanueva";
            //pass = "marcos_vilhanueva";
            url = "jdbc:mysql://10.7.0.51:33062/db_victoria_ruback";
            user = "victoria_ruback";
            pass = "victoria_ruback";
            cnt = DriverManager.getConnection(url, user, pass);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ClientesDao.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ClientesDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void insert(Object object) {
        Clientes var_clientes = (Clientes) object;
        try {
            PreparedStatement pst = cnt.prepareStatement(
                    "INSERT INTO var_clientes VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
            );
            pst.setInt(1, var_clientes.getVar_idCliente());
            pst.setString(2, var_clientes.getVar_nome());
            pst.setString(3, var_clientes.getVar_cpf());
            pst.setString(4, var_clientes.getVar_rg());
            pst.setString(5, var_clientes.getVar_sexo());
            pst.setDate(6, null);
            pst.setString(7, var_clientes.getVar_email());
            pst.setString(8, var_clientes.getVar_endereco());
            pst.setString(9, var_clientes.getVar_telefone());
            pst.setString(10, var_clientes.getVar_celular());
            pst.setDate(11, null);
            pst.setString(12, var_clientes.getVar_ativo());
            pst.setDate(13, null);
            pst.setDouble(14, var_clientes.getVar_limiteCredito());

            pst.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(ClientesDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void update(Object object) {
        Clientes var_clientes = (Clientes) object;
        try {
            PreparedStatement pst = cnt.prepareStatement(
                    "UPDATE var_clientes SET var_nome=?, var_cpf=?, var_rg=?, var_sexo=?, var_dataNascimento=?, var_email=?, var_endereco=?, var_telefone=?, var_celular=?, var_dataCadastro=?, var_ativo=?, var_dataUltimaCompra=?, var_limiteCredito=? WHERE var_idCliente=?"
            );
            pst.setString(1, var_clientes.getVar_nome());
            pst.setString(2, var_clientes.getVar_cpf());
            pst.setString(3, var_clientes.getVar_rg());
            pst.setString(4, var_clientes.getVar_sexo());
            pst.setDate(5, null);
            pst.setString(6, var_clientes.getVar_email());
            pst.setString(7, var_clientes.getVar_endereco());
            pst.setString(8, var_clientes.getVar_telefone());
            pst.setString(9, var_clientes.getVar_celular());
            pst.setDate(10, null);
            pst.setString(11, var_clientes.getVar_ativo());
            pst.setDate(12, null);
            pst.setDouble(13, var_clientes.getVar_limiteCredito());
            pst.setInt(14, var_clientes.getVar_idCliente());

            pst.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(ClientesDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void delete(Object object) {
        Clientes var_clientes = (Clientes) object;
        try {
            PreparedStatement pst = cnt.prepareStatement("DELETE FROM var_clientes WHERE var_idCliente=?");
            pst.setInt(1, var_clientes.getVar_idCliente());
            pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ClientesDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public Object list(int id) {
        try {
            PreparedStatement pst = cnt.prepareStatement("SELECT * FROM var_clientes WHERE var_idCliente=?");
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                Clientes var_clientes = new Clientes();
                var_clientes.setVar_idCliente(rs.getInt("var_idCliente"));
                var_clientes.setVar_nome(rs.getString("var_nome"));
                var_clientes.setVar_cpf(rs.getString("var_cpf"));
                var_clientes.setVar_rg(rs.getString("var_rg"));
                var_clientes.setVar_sexo(rs.getString("var_sexo"));
                var_clientes.setVar_dataNascimento(rs.getDate("var_dataNascimento"));
                var_clientes.setVar_email(rs.getString("var_email"));
                var_clientes.setVar_endereco(rs.getString("var_endereco"));
                var_clientes.setVar_telefone(rs.getString("var_telefone"));
                var_clientes.setVar_celular(rs.getString("var_celular"));
                var_clientes.setVar_dataCadastro(rs.getDate("var_dataCadastro"));
                var_clientes.setVar_ativo(rs.getString("var_ativo"));
                var_clientes.setVar_dataUltimaCompra(rs.getDate("var_dataUltimaCompra"));
                var_clientes.setVar_limiteCredito(rs.getDouble("var_limiteCredito"));
                return var_clientes;
            }
        } catch (SQLException ex) {
            Logger.getLogger(ClientesDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    public Object listAll() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public static void main(String[] args) {
        // Criando um objeto Cliente com dados fictícios
        Clientes cliente = new Clientes();

        // Preenchendo com dados de exemplo
        cliente.setVar_idCliente(75);
        cliente.setVar_nome("victoria");
        cliente.setVar_cpf("12345678900");
        cliente.setVar_rg("123456");
        cliente.setVar_sexo("M");
        cliente.setVar_dataNascimento(null);
        cliente.setVar_email("joao.silva@email.com");
        cliente.setVar_endereco("Rua das Flores, 123 - Centro");
        cliente.setVar_telefone("(11) 2222-3333");
        cliente.setVar_celular("(11) 98877-6655");
        cliente.setVar_dataCadastro(null);
        cliente.setVar_ativo("S");
        cliente.setVar_dataUltimaCompra(null);
        cliente.setVar_limiteCredito(5000.00);

        // Inserindo no banco de dados
        ClientesDao clientesDao = new ClientesDao();
        clientesDao.insert(cliente);

        System.out.println("Cliente inserido com sucesso!");
        System.out.println("ID: " + cliente.getVar_idCliente());
        System.out.println("Nome: " + cliente.getVar_nome());
        System.out.println("CPF: " + cliente.getVar_cpf());
    }

}
