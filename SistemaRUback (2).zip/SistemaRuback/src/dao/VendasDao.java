/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.Date;
import bean.Vendas;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author marcos
 */
public class VendasDao extends DaoAbstract {

    Connection cnt;

    public VendasDao() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url, user, pass;
            //url = "jdbc:mysql://10.7.0.51:330622/db_marcos_vilhanueva";
            //user = "marcos_vilhanueva";
            //pass = "marcos_vilhanueva";
            url = "jdbc:mysql://10.7.0.51:33062/db_victoria_ruback";
            user = "victoria_ruback";
            pass = "victoria_ruback";
            cnt = DriverManager.getConnection(url, user, pass);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(VendasDao.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(VendasDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void insert(Object object) {
        Vendas vendas = (Vendas) object;
        try {
            PreparedStatement pst = cnt.prepareStatement("INSERT INTO var_vendas (var_idVendas, var_dataVendas, var_cliente, var_usuario, var_total) VALUES (?, ?, ?, ?, ?)");
            pst.setInt(1, vendas.getVar_idVendas());
            pst.setDate(2, null);
            pst.setInt(3, vendas.getVar_cliente());
            pst.setInt(4, vendas.getVar_usuario());
            pst.setDouble(5, vendas.getVar_total());
            pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(VendasDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void update(Object object) {
        Vendas vendas = (Vendas) object;
        try {
            PreparedStatement pst = cnt.prepareStatement("UPDATE var_vendas SET var_dataVendas = ?, var_cliente = ?, var_usuario = ?, var_total = ? WHERE var_idVendas = ?");
            pst.setDate(1, null);
            pst.setInt(2, vendas.getVar_cliente());
            pst.setInt(3, vendas.getVar_usuario());
            pst.setDouble(4, vendas.getVar_total());
            pst.setInt(5, vendas.getVar_idVendas());
            pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(VendasDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void delete(Object object) {
        Vendas vendas = (Vendas) object;
        try {
            PreparedStatement pst = cnt.prepareStatement("DELETE FROM var_vendas WHERE var_idVendas = ?");
            pst.setInt(1, vendas.getVar_idVendas());
            pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(VendasDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public Object list(int id) {
        try {
            PreparedStatement pst = cnt.prepareStatement("SELECT * FROM var_vendas WHERE var_idVendas = ?");
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                Vendas vendas = new Vendas();
                vendas.setVar_idVendas(rs.getInt("var_idVendas"));
                vendas.setVar_dataVendas(null);
                vendas.setVar_cliente(rs.getInt("var_cliente"));
                vendas.setVar_usuario(rs.getInt("var_usuario"));
                vendas.setVar_total(rs.getDouble("var_total"));
                return vendas;
            }
        } catch (SQLException ex) {
            Logger.getLogger(VendasDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    public Object listAll() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public static void main(String[] args) {
        Vendas venda = new Vendas();
        venda.setVar_idVendas(1);
        venda.setVar_dataVendas(null);
        venda.setVar_cliente(1);
        venda.setVar_usuario(1);
        venda.setVar_total(99.90);

        VendasDao dao = new VendasDao();
        dao.insert(venda);

        System.out.println("Venda inserida com sucesso!");
    }

}
