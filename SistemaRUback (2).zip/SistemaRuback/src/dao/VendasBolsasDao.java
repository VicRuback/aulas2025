/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import bean.VendasBolsas;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author marcos
 */
public class VendasBolsasDao extends DaoAbstract {

    Connection cnt;

    public VendasBolsasDao() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url, user, pass;
            //url = "jdbc:mysql://10.7.0.51:330622/db_marcos_vilhanueva";
            //user = "marcos_vilhanueva";
            //pass = "marcos_vilhanueva";
            url = "jdbc:mysql://10.7.0.51:33062/db_victoria_ruback";
            user = "victoria_ruback";
            pass = "victoria_ruback";
            cnt = DriverManager.getConnection(url, user, pass);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(VendasBolsasDao.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(VendasBolsasDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void insert(Object object) {
           VendasBolsas vb = (VendasBolsas) object;
        String sql = "INSERT INTO var_vendas_bolsas (var_idVendas_bolsas, var_bolsas, var_quantidade, var_valor_unitario) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pst = cnt.prepareStatement(sql)) {
            pst.setInt(1, vb.getVar_idVenda());
            pst.setInt(2, vb.getVar_idBolsa());
            pst.setInt(3, vb.getVar_quantidade());
            pst.setDouble(4, vb.getVar_precoUnitario());
            pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(VendasBolsasDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void update(Object object) {
        VendasBolsas vb = (VendasBolsas) object;
        String sql = "UPDATE var_vendas_bolsas SET var_idVendas_bolsas = ?, var_bolsas = ?, var_quantidade = ?, var_valor_unitario = ? WHERE var_id = ?";
        try (PreparedStatement pst = cnt.prepareStatement(sql)) {
            pst.setInt(1, vb.getVar_idVenda());
            pst.setInt(2, vb.getVar_idBolsa());
            pst.setInt(3, vb.getVar_quantidade());
            pst.setDouble(4, vb.getVar_precoUnitario());
            pst.setInt(5, vb.getVar_id());
            pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(VendasBolsasDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void delete(Object object) {
        VendasBolsas vb = (VendasBolsas) object;
        String sql = "DELETE FROM var_vendas_bolsas WHERE var_id = ?";
        try (PreparedStatement pst = cnt.prepareStatement(sql)) {
            pst.setInt(1, vb.getVar_id());
            pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(VendasBolsasDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public Object list(int id) {
       String sql = "SELECT * FROM var_vendas_bolsas WHERE var_id = ?";
        try (PreparedStatement pst = cnt.prepareStatement(sql)) {
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                VendasBolsas vb = new VendasBolsas();
                vb.setVar_id(rs.getInt("var_id"));
                vb.setVar_idVenda(rs.getInt("var_idVendas_bolsas"));
                vb.setVar_idBolsa(rs.getInt("var_bolsas"));
                vb.setVar_quantidade(rs.getInt("var_quantidade"));
                vb.setVar_precoUnitario(rs.getDouble("var_valor_unitario"));
                return vb;
            }
        } catch (SQLException ex) {
            Logger.getLogger(VendasBolsasDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    public Object listAll() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public static void main(String[] args) {
        VendasBolsas vb = new VendasBolsas();
        vb.setVar_idVenda(1);      
        vb.setVar_idBolsa(1);        
        vb.setVar_quantidade(2);     
        vb.setVar_precoUnitario(79.90); 

        VendasBolsasDao dao = new VendasBolsasDao();
        dao.insert(vb);

        System.out.println("Venda de bolsa inserida com sucesso!");
    }

}
