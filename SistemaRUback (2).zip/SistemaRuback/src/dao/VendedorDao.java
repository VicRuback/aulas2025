/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import bean.Vendedor;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author marcos
 */
public class VendedorDao extends DaoAbstract {

    Connection cnt;

    public VendedorDao() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url, user, pass;
            //url = "jdbc:mysql://10.7.0.51:330622/db_marcos_vilhanueva";
            //user = "marcos_vilhanueva";
            //pass = "marcos_vilhanueva";
            url = "jdbc:mysql://10.7.0.51:33062/db_victoria_ruback";
            user = "victoria_ruback";
            pass = "victoria_ruback";
            cnt = DriverManager.getConnection(url, user, pass);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(VendedorDao.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(VendedorDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void insert(Object object) {
        Vendedor vendedor = (Vendedor) object;
        try {
            PreparedStatement pst = cnt.prepareStatement("insert into var_vendedores values(?,?,?,?,?,?,?,?)");
            pst.setInt(1, vendedor.getVar_id_vendedor());
            pst.setString(2, vendedor.getVar_nome());
            pst.setString(3, vendedor.getVar_apelido());
            pst.setString(4, vendedor.getVar_cpf());
            pst.setString(5, vendedor.getVar_email());
            pst.setDate(6, vendedor.getVar_data_nascimento());
            pst.setString(7, vendedor.getVar_telefone());
            pst.setString(8, vendedor.getVar_ativo());
            pst.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(VendedorDao.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @Override
    public void update(Object object) {
        Vendedor vendedor = (Vendedor) object;
        try {
            PreparedStatement pst = cnt.prepareStatement(
                    "update var_vendedores set var_nome=?, var_apelido=?, var_cpf=?, var_email=?, var_data_nascimento=?, var_telefone=?, var_ativo=? where var_id_vendedor=?"
            );
            pst.setString(1, vendedor.getVar_nome());
            pst.setString(2, vendedor.getVar_apelido());
            pst.setString(3, vendedor.getVar_cpf());
            pst.setString(4, vendedor.getVar_email());
            pst.setDate(5, vendedor.getVar_data_nascimento());
            pst.setString(6, vendedor.getVar_telefone());
            pst.setString(7, vendedor.getVar_ativo());
            pst.setInt(8, vendedor.getVar_id_vendedor());
            pst.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(VendedorDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void delete(Object object) {
        Vendedor vendedor = (Vendedor) object;
        try {
            PreparedStatement pst = cnt.prepareStatement("delete from var_vendedores where var_id_vendedor = ?");
            pst.setInt(1, vendedor.getVar_id_vendedor());
            pst.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(VendedorDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public Object list(int id) {
        PreparedStatement pst;
        try {
            pst = cnt.prepareStatement("select * from var_vendedores where var_id_vendedor =?");
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();
            if (rs.next() == true) {
                Vendedor vendedor = new Vendedor();
                vendedor.setVar_id_vendedor(rs.getInt("var_id_vendedor"));
                vendedor.setVar_nome(rs.getString("var_nome"));
                vendedor.setVar_apelido(rs.getString("var_apelido"));
                vendedor.setVar_cpf(rs.getString("var_cpf"));
                vendedor.setVar_email(rs.getString("var_email"));
                vendedor.setVar_data_nascimento(rs.getDate("var_data_nascimento"));
                vendedor.setVar_telefone(rs.getString("var_telefone"));
                vendedor.setVar_ativo(rs.getString("var_ativo"));

                return vendedor;
            }
        } catch (SQLException ex) {
            Logger.getLogger(VendedorDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    public Object listAll() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public static void main(String[] args) {
        // Criando um objeto Vendedor com dados fictícios
        Vendedor vendedor = new Vendedor();

        // Preenchendo com dados de exemplo (CPF e RG apenas números)
        vendedor.setVar_id_vendedor(1);
        vendedor.setVar_nome("Carlos Oliveira");
        vendedor.setVar_apelido("carlos");
        vendedor.setVar_cpf("12345678901"); // CPF apenas números
        vendedor.setVar_email("carlos.oliveira@empresa.com");
        vendedor.setVar_data_nascimento(java.sql.Date.valueOf("1988-07-15"));
        vendedor.setVar_telefone("11987654321"); // Telefone apenas números
        vendedor.setVar_ativo("S");

        // Inserindo no banco de dados
        VendedorDao vendedorDao = new VendedorDao();
        vendedorDao.insert(vendedor);

        System.out.println("Vendedor inserido com sucesso!");
        System.out.println("ID: " + vendedor.getVar_id_vendedor());
        System.out.println("Nome: " + vendedor.getVar_nome());
        System.out.println("CPF: " + vendedor.getVar_cpf());
        System.out.println("Telefone: " + vendedor.getVar_telefone());
    }

}
